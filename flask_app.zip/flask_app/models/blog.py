from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash